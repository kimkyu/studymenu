package com.example.lg_user.project.model;

/**
 * Created by LG-USER on 2018-04-03.
 */

public class UserModel {
    public String userName;
    public String profileImageUrl;
    public String uid;
}
